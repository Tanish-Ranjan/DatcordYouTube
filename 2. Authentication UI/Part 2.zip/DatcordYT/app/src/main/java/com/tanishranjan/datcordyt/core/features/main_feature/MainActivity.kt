package com.tanishranjan.datcordyt.core.features.main_feature

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.tanishranjan.datcordyt.core.features.navigation_feature.ui.MainNavigation
import com.tanishranjan.datcordyt.core.ui.theme.DatcordYTTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DatcordYTTheme {

                MainNavigation()

            }
        }
    }
}