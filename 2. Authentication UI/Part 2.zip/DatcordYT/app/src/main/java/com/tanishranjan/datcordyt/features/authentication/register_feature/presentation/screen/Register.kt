package com.tanishranjan.datcordyt.features.authentication.register_feature.presentation.screen

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tanishranjan.datcordyt.R
import com.tanishranjan.datcordyt.core.ui.composables.CustomTabBar
import com.tanishranjan.datcordyt.core.ui.composables.CustomTextField

@Composable
fun RegisterScreen(
    onBackClick: () -> Unit,
    onNext: () -> Unit
) {

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colors.background
    ) {

        Column(Modifier.fillMaxSize()) {

            Row(Modifier.fillMaxWidth()) {

                IconButton(
                    onClick = onBackClick
                ) {
                    Icon(
                        painterResource(R.drawable.ic_back),
                        null
                    )
                }

            }

            Spacer(Modifier.height(4.dp))

            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {

                Text(
                    "Enter phone or email",
                    style = MaterialTheme.typography.h3,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(16.dp))

                var selectedTabIndex by remember {
                    mutableStateOf(0)
                }

                CustomTabBar(
                    listOf("Phone", "Email"),
                    Modifier.fillMaxWidth(),
                    onTabChange = { newTabIndex ->
                        selectedTabIndex = newTabIndex
                    },
                    defaultSelectedIndex = 0
                )

                Spacer(Modifier.height(24.dp))

                Text(
                    if (selectedTabIndex == 0) "PHONE NUMBER" else "EMAIL",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colors.onBackground.copy(0.7f)
                )

                Spacer(Modifier.height(8.dp))

                Row(
                    Modifier
                        .height(IntrinsicSize.Max)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colors.secondary)
                ) {

                    AnimatedVisibility(visible = selectedTabIndex == 0) {

                        Row {
                            Box(
                                Modifier
                                    .fillMaxHeight()
                                    .clickable {

                                    }
                                    .padding(horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("US +1", style = MaterialTheme.typography.body2)
                            }
                            Box(
                                Modifier
                                    .padding(vertical = 2.dp)
                                    .fillMaxHeight()
                                    .width(1.dp)
                                    .background(MaterialTheme.colors.background)
                            )
                        }

                    }

                    var emailAndPhone by remember {
                        mutableStateOf("")
                    }

                    CustomTextField(
                        value = emailAndPhone,
                        hint = if (selectedTabIndex == 0) "Phone Number" else "Email",
                        backColor = Color.Transparent,
                        modifier = Modifier.weight(1f),
                        onValueChange = { newValue ->
                            emailAndPhone = newValue
                        }
                    )

                }

                Spacer(Modifier.height(8.dp))

                Text(
                    "View our Privacy Policy",
                    color = MaterialTheme.colors.primaryVariant,
                    fontSize = 12.sp,
                    modifier = Modifier.clickable {
                        // TODO: Naivigate to privacy policy page
                    }
                )

                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = {
                        // TODO: Call the viewModel function
                    },
                    modifier = Modifier
                        .height(42.dp)
                        .fillMaxWidth()
                ) {
                    Text("Next")
                }

            }

        }

    }

}