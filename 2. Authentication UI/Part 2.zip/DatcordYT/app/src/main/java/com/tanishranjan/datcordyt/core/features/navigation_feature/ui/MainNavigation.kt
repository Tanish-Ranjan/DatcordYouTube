package com.tanishranjan.datcordyt.core.features.navigation_feature.ui

import androidx.compose.animation.AnimatedContentScope
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.navigation
import com.google.accompanist.navigation.animation.AnimatedNavHost
import com.google.accompanist.navigation.animation.composable
import com.google.accompanist.navigation.animation.rememberAnimatedNavController
import com.tanishranjan.datcordyt.core.features.navigation_feature.data.NavigationRoutes
import com.tanishranjan.datcordyt.features.authentication.login_feature.presentation.screen.LoginScreen
import com.tanishranjan.datcordyt.features.authentication.register_feature.presentation.screen.RegisterScreen
import com.tanishranjan.datcordyt.features.authentication.startup_feature.presentation.screen.StartupScreen
import com.tanishranjan.datcordyt.features.home_feature.presentation.screen.HomeScreen
import com.tanishranjan.datcordyt.features.splash_feature.presentation.screen.SplashScreen

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MainNavigation() {

    val controller = rememberAnimatedNavController()

    AnimatedNavHost(
        navController = controller,
        startDestination = NavigationRoutes.Splash.route,
        modifier = Modifier.fillMaxSize()
    ) {

        composable(NavigationRoutes.Splash.route,
            enterTransition = { fadeIn(tween(500)) },
            popEnterTransition = { fadeIn(tween(500)) },
            exitTransition = { fadeOut(tween(500)) },
            popExitTransition = { fadeOut(tween(500)) }
        ) {
            SplashScreen { isLoggedIn ->
                if (isLoggedIn) {
                    controller.popBackStack()
                    controller.navigate(NavigationRoutes.App.route) {
                        launchSingleTop = true
                    }
                } else {
                    controller.popBackStack()
                    controller.navigate(NavigationRoutes.Auth.route) {
                        launchSingleTop = true
                    }
                }
            }
        }

        navigation(
            startDestination = NavigationRoutes.StartUp.route,
            route = NavigationRoutes.Auth.route
        ) {

            composable(
                NavigationRoutes.StartUp.route,
                enterTransition = { fadeIn(tween(500)) },
                popEnterTransition = { fadeIn(tween(500)) },
                exitTransition = { fadeOut(tween(500)) },
                popExitTransition = { fadeOut(tween(500)) }
            ) {

                StartupScreen(onClickRegister = {
                    controller.navigate(NavigationRoutes.Register.route) {
                        launchSingleTop = true
                    }
                }, onClickLogin = {
                    controller.navigate(NavigationRoutes.Login.route) {
                        launchSingleTop = true
                    }
                })

            }

            composable(
                NavigationRoutes.Login.route,
                enterTransition = {
                    slideIntoContainer(
                        AnimatedContentScope.SlideDirection.Left,
                        tween(300)
                    )
                },
                popEnterTransition = {
                    slideIntoContainer(
                        AnimatedContentScope.SlideDirection.Left,
                        tween(300)
                    )
                },
                exitTransition = {
                    slideOutOfContainer(
                        AnimatedContentScope.SlideDirection.Right,
                        tween(300)
                    )
                },
                popExitTransition = {
                    slideOutOfContainer(
                        AnimatedContentScope.SlideDirection.Right,
                        tween(300)
                    )
                }
            ) {

                LoginScreen(onBackClick = {
                    controller.popBackStack()
                }, onLogin = {
                    controller.popBackStack(NavigationRoutes.Auth.route, true)
                    controller.navigate(NavigationRoutes.App.route) {
                        launchSingleTop = true
                    }
                })

            }

            composable(
                NavigationRoutes.Register.route,
                enterTransition = {
                    slideIntoContainer(
                        AnimatedContentScope.SlideDirection.Left,
                        tween(300)
                    )
                },
                popEnterTransition = {
                    slideIntoContainer(
                        AnimatedContentScope.SlideDirection.Left,
                        tween(300)
                    )
                },
                exitTransition = {
                    slideOutOfContainer(
                        AnimatedContentScope.SlideDirection.Right,
                        tween(300)
                    )
                },
                popExitTransition = {
                    slideOutOfContainer(
                        AnimatedContentScope.SlideDirection.Right,
                        tween(300)
                    )
                }
            ) {

                RegisterScreen(onBackClick = {
                    controller.popBackStack()
                }, onNext = {
                    // TODO: Navigate to next screen
                })

            }

        }

        navigation(
            startDestination = NavigationRoutes.Home.route,
            route = NavigationRoutes.App.route
        ) {

            composable(NavigationRoutes.Home.route) {

                HomeScreen()

            }

        }

    }

}