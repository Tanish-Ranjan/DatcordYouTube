package com.tanishranjan.datcordyt.features.home_feature.presentation.screen

import androidx.compose.foundation.layout.Column
import androidx.compose.material.Text
import androidx.compose.runtime.Composable

@Composable
fun HomeScreen() {

    Column {

        Text("This is the home screen")

    }

}