package com.tanishranjan.datcordyt.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF5865F2)
val EngravedSurface = Color(0xFF1E1F23)
val Surface = Color(0xFF40434A)
val Background = Color(0xFF323338)
val Highlight = Color(0xFF0EA6EF)
